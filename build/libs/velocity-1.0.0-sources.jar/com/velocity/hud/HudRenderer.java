package com.velocity.hud;

import com.velocity.VelocityMod;
import com.velocity.config.ConfigManager;
import com.velocity.module.VelocityModule;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class HudRenderer {

    public void init() {
        VelocityMod.LOGGER.info("[Velocity] HudRenderer registering...");
        HudRenderCallback.EVENT.register((class_332 ctx, class_9779 tc) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null) return;
            if (client.field_1755 != null) return;

            VelocityModule module = VelocityMod.getInstance().getModuleManager().getVelocityModule();
            if (!module.isEnabled()) return;

            ConfigManager config = VelocityMod.getInstance().getConfigManager();
            var tr = client.field_1772;
            int sw = client.method_22683().method_4486();
            int sh = client.method_22683().method_4502();

            String line = "Velocity " + String.format("%.1f", config.getSpeedMultiplier()) + "x";
            int tw = tr.method_1727(line);
            int x = sw - tw - 2;
            int y = sh - tr.field_2000 - 38;

            ctx.method_25294(x - 2, y - 2, x + tw + 2, y + tr.field_2000 + 2, (160 << 24) | 0x333333);
            ctx.method_25303(tr, line, x, y, 0x808080);
        });
        VelocityMod.LOGGER.info("[Velocity] HudRenderer registered!");
    }
}
