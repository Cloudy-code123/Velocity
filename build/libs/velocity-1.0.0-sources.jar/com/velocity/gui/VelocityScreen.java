package com.velocity.gui;

import com.velocity.VelocityMod;
import com.velocity.config.ConfigManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;

public class VelocityScreen extends class_437 {

    private final ConfigManager config = VelocityMod.getInstance().getConfigManager();

    public VelocityScreen() {
        super(class_2561.method_43470("Velocity"));
    }

    @Override
    protected void method_25426() {
        int w = 130;
        int x = this.field_22789 - w - 5;
        int y = this.field_22790 - 90;

        this.method_37063(new SliderWidget(
                x, y, w, 14, class_2561.method_43470("Speed"),
                1.0, 10.0, config.getSpeedMultiplier(),
                config::setSpeedMultiplier
        ));

        y += 18;

        this.method_37063(new SliderWidget(
                x, y, w, 14, class_2561.method_43470("Accel"),
                0.1, 1.0, config.getAcceleration(),
                config::setAcceleration
        ));

        y += 18;

        this.method_37063(class_4286.method_54787(
                class_2561.method_43470("Sprint"), this.field_22793
        ).method_54789(x, y).method_54794(config.isSprintBoost()).method_54791((b, c) -> config.setSprintBoost(c)).method_54788());

        y += 16;

        this.method_37063(class_4286.method_54787(
                class_2561.method_43470("Jump"), this.field_22793
        ).method_54789(x, y).method_54794(config.isJumpBoost()).method_54791((b, c) -> config.setJumpBoost(c)).method_54788());

        y += 18;

        this.method_37063(
                class_4185.method_46430(class_2561.method_43470("Done"), b -> this.method_25419())
                        .method_46434(x, y, 50, 14).method_46431()
        );
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
