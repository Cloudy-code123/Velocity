package com.velocity.gui;

import java.util.function.DoubleConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6381;
import net.minecraft.class_6382;

/**
 * A custom horizontal slider widget for adjusting double values within a range.
 * Supports mouse click and drag for smooth value selection.
 */
public class SliderWidget extends class_339 {

    private double normalizedValue;
    private final double minValue;
    private final double maxValue;
    private final class_2561 label;
    private final DoubleConsumer onChange;

    // Rendering constants
    private static final int TRACK_HEIGHT = 10;
    private static final int HANDLE_WIDTH = 4;

    /**
     * Creates a new slider widget.
     *
     * @param x            the x position
     * @param y            the y position
     * @param width        the total widget width
     * @param height       the total widget height (including label area)
     * @param label        the label to display above the slider
     * @param minValue     the minimum value
     * @param maxValue     the maximum value
     * @param currentValue the initial value
     * @param onChange      callback when the value changes
     */
    public SliderWidget(int x, int y, int width, int height, class_2561 label,
                        double minValue, double maxValue, double currentValue,
                        DoubleConsumer onChange) {
        super(x, y, width, height, label);
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.label = label;
        this.onChange = onChange;

        double range = maxValue - minValue;
        this.normalizedValue = (range > 0) ? (currentValue - minValue) / range : 0.0;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();
        int trackX = this.method_46426();
        int trackY = this.method_46427() + 14;
        int trackWidth = this.method_25368();
        int handleX = (int) (trackX + trackWidth * this.normalizedValue);

        // Track background
        context.method_25294(trackX, trackY, trackX + trackWidth, trackY + TRACK_HEIGHT, 0xFF404040);

        // Filled portion
        context.method_25294(trackX, trackY, handleX, trackY + TRACK_HEIGHT, 0xFF5599FF);

        // Handle
        context.method_25294(
                handleX - HANDLE_WIDTH / 2, trackY - 1,
                handleX + HANDLE_WIDTH / 2, trackY + TRACK_HEIGHT + 1,
                0xFFDDDDDD
        );

        // Label with current value
        double actualValue = getActualValue();
        String displayText = label.getString() + ": " + String.format("%.1f", actualValue);
        context.method_25300(
                client.field_1772,
                displayText,
                this.method_46426() + this.method_25368() / 2,
                this.method_46427(),
                0xFFFFFF
        );
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        updateValueFromMouse(mouseX);
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double deltaX, double deltaY) {
        updateValueFromMouse(mouseX);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button,
                                double deltaX, double deltaY) {
        // Allow dragging outside widget bounds for better UX
        if (this.field_22763 && this.field_22764 && button == 0) {
            this.method_25349(mouseX, mouseY, deltaX, deltaY);
            return true;
        }
        return false;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        builder.method_37034(class_6381.field_33788, this.method_25369());
    }

    /**
     * Updates the slider value based on the mouse X position.
     *
     * @param mouseX the current mouse X coordinate
     */
    private void updateValueFromMouse(double mouseX) {
        double relative = (mouseX - this.method_46426()) / (double) this.method_25368();
        this.normalizedValue = clamp(relative, 0.0, 1.0);

        double actualValue = getActualValue();
        // Round to 1 decimal place for clean values
        actualValue = Math.round(actualValue * 10.0) / 10.0;
        onChange.accept(actualValue);
    }

    /** Returns the current actual value within the configured range. */
    public double getActualValue() {
        return minValue + normalizedValue * (maxValue - minValue);
    }

    /** Sets the slider to a specific actual value. */
    public void setActualValue(double value) {
        double range = maxValue - minValue;
        if (range > 0) {
            this.normalizedValue = clamp((value - minValue) / range, 0.0, 1.0);
        }
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
