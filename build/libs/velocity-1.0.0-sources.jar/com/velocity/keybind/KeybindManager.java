package com.velocity.keybind;

import com.velocity.VelocityMod;
import com.velocity.gui.VelocityScreen;
import com.velocity.module.VelocityModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Manages all keybindings for the Velocity mod.
 * Registers the toggle key (") and the settings GUI key (HOME).
 */
public class KeybindManager {

    private class_304 toggleKey;
    private class_304 settingsKey;

    /** Initializes and registers all keybindings, then hooks into the client tick. */
    public void init() {
        // Toggle key: " key (apostrophe key on standard layout)
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.velocity.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_APOSTROPHE,
                "category.velocity"
        ));

        // Settings GUI key: HOME
        settingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.velocity.settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_HOME,
                "category.velocity"
        ));

        // Listen for key presses each client tick
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
    }

    /**
     * Processes keybind presses each tick.
     *
     * @param client the Minecraft client instance
     */
    private void onClientTick(class_310 client) {
        if (client.field_1724 == null) return;

        // Handle toggle key
        while (toggleKey.method_1436()) {
            if (client.field_1755 != null) continue;

            VelocityModule module = VelocityMod.getInstance().getModuleManager().getVelocityModule();
            module.toggle();
        }

        // Handle settings key — open or close GUI
        while (settingsKey.method_1436()) {
            if (client.field_1755 instanceof VelocityScreen) {
                client.method_1507(null);
            } else if (client.field_1755 == null) {
                client.method_1507(new VelocityScreen());
            }
        }
    }
}
