package com.velocity.mixin;

import com.velocity.VelocityMod;
import com.velocity.module.VelocityModule;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @ModifyVariable(method = "travel", at = @At("HEAD"), argsOnly = true)
    private class_243 velocity$scaleMovementInput(class_243 movementInput) {
        if (!((Object) this instanceof class_1657)) return movementInput;
        if (!((class_1309)(Object)this).method_37908().method_8608()) return movementInput;

        class_746 player = (class_746) (Object) this;
        VelocityModule module = VelocityMod.getInstance().getModuleManager().getVelocityModule();
        module.tick(player);

        if (!module.isEnabled()) return movementInput;

        double multiplier = module.getCurrentEffectiveMultiplier();
        return new class_243(
                movementInput.field_1352 * multiplier,
                movementInput.field_1351,
                movementInput.field_1350 * multiplier
        );
    }

    @Inject(method = "jump", at = @At("TAIL"))
    private void velocity$applyJumpBoost(CallbackInfo ci) {
        if (!((Object) this instanceof class_1657)) return;
        if (!((class_1309)(Object)this).method_37908().method_8608()) return;

        class_746 player = (class_746) (Object) this;
        VelocityModule module = VelocityMod.getInstance().getModuleManager().getVelocityModule();
        module.onJump(player);
    }

    @Inject(method = "takeKnockback", at = @At("HEAD"), cancellable = true)
    private void velocity$cancelKnockback(double strength, double x, double z, CallbackInfo ci) {
        try {
            if (!((Object) this instanceof class_746)) return;

            VelocityModule module = VelocityMod.getInstance().getModuleManager().getVelocityModule();
            if (!module.isEnabled()) return;

            ci.cancel();
        } catch (Exception ignored) {
        }
    }
}
