package com.velocity.mixin;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Mixin placeholder — speed boost logic is handled in LivingEntityMixin
 * via @ModifyVariable on travel(), which is more compatible with 1.21.7's
 * immutable Input/PlayerInput record types.
 */
@Mixin(class_746.class)
public abstract class ClientPlayerMixin {
}
