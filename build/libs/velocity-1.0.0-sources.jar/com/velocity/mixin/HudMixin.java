package com.velocity.mixin;

import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class HudMixin {

    @Inject(method = "render", at = @At("RETURN"))
    private void velocity$renderHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        var tr = client.field_1772;
        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();

        String text = "Velocity";
        int tw = tr.method_1727(text);
        int x = sw - tw - 4;
        int y = sh - 40;

        context.method_25303(tr, text, x, y, 0x964B00);
    }
}
