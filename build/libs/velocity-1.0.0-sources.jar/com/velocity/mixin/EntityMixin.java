package com.velocity.mixin;

import com.velocity.VelocityMod;
import com.velocity.module.VelocityModule;
import net.minecraft.class_1297;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public abstract class EntityMixin {

    @Unique
    private boolean velocity$isClientPlayer() {
        return (Object) this instanceof class_746;
    }

    @Inject(method = "setVelocityClient", at = @At("HEAD"), cancellable = true)
    private void velocity$cancelKnockback(double x, double y, double z, CallbackInfo ci) {
        try {
            if (!velocity$isClientPlayer()) return;

            VelocityModule module = VelocityMod.getInstance().getModuleManager().getVelocityModule();
            if (!module.isEnabled()) return;

            ci.cancel();
        } catch (Exception ignored) {
        }
    }
}
